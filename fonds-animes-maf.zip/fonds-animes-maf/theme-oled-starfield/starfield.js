// Starfield animation
let starfieldAnimId = null
let warpFactor = 1      // multiplicateur de vitesse courant
let warpTarget = 1      // multiplicateur cible (1 = normal, 20 = hyperspeed)
let warpScale = 1       // zoom courant du canvas
let warpScaleTarget = 1 // zoom cible

function triggerWarp() {
  warpTarget = 20
  warpScaleTarget = 1.08
  setTimeout(() => {
    warpTarget = 1
    warpScaleTarget = 1
  }, 350)
}

function initStarfield() {
  const canvas = document.getElementById('starfield-canvas')
  if (!canvas) return
  const ctx = canvas.getContext('2d')
  let stars = []
  let w, h
  let frame = 0

  function makeStar(xOverride) {
    // Angle légèrement dévié autour de la verticale (-15° à +15°)
    const angle = (Math.random() - 0.5) * (Math.PI / 6)
    const speed = Math.random() * 0.9 + 0.15
    return {
      x: xOverride !== undefined ? xOverride : Math.random() * w,
      y: Math.random() * h,
      radius: Math.pow(Math.random(), 2) * 1.8 + 0.2, // plus de petites étoiles
      baseAlpha: Math.random() * 0.7 + 0.2,
      twinkleSpeed: Math.random() * 0.04 + 0.005, // fréquence scintillement
      twinkleOffset: Math.random() * Math.PI * 2,  // phase aléatoire unique
      vx: Math.sin(angle) * speed,                 // drift horizontal
      vy: -Math.cos(angle) * speed,                // mouvement principal vers le haut
    }
  }

  function resize() {
    w = canvas.width = window.innerWidth
    h = canvas.height = window.innerHeight
    stars = Array.from({ length: 70 }, () => makeStar())
  }

  function animate() {
    frame++
    warpFactor += (warpTarget - warpFactor) * 0.15
    warpScale += (warpScaleTarget - warpScale) * 0.12

    ctx.clearRect(0, 0, w, h)

    const cx = w / 2
    const cy = h / 2
    ctx.save()
    ctx.translate(cx, cy)
    ctx.scale(warpScale, warpScale)
    ctx.translate(-cx, -cy)

    stars.forEach(s => {
      const vx = s.vx * warpFactor
      const vy = s.vy * warpFactor
      const speed = Math.sqrt(vx * vx + vy * vy)

      // Scintillement uniquement hors warp
      const twinkle = warpFactor < 2
        ? Math.sin(frame * s.twinkleSpeed + s.twinkleOffset) * 0.25
        : 0
      const alpha = Math.max(0.05, Math.min(1, s.baseAlpha + twinkle))

      ctx.globalAlpha = alpha

      const trailLength = warpFactor > 2 ? speed * 2 : 0
      if (trailLength > 0) {
        // Traînée dans la direction du mouvement
        const nx = vx / speed
        const ny = vy / speed
        ctx.beginPath()
        ctx.moveTo(s.x - nx * trailLength, s.y - ny * trailLength)
        ctx.lineTo(s.x, s.y)
        ctx.strokeStyle = `rgba(255,255,255,${alpha * 0.7})`
        ctx.lineWidth = s.radius * 1.2
        ctx.stroke()
      } else {
        ctx.fillStyle = '#fff'
        ctx.fillRect(s.x - s.radius, s.y - s.radius, s.radius * 2, s.radius * 2)
      }

      s.x += vx
      s.y += vy

      // Réapparition en bas avec nouvelle x aléatoire pour briser la répétition
      if (s.y < -10 || s.x < -10 || s.x > w + 10) {
        const newStar = makeStar()
        newStar.y = h + 5
        Object.assign(s, newStar)
      }
    })

    ctx.restore()
    starfieldAnimId = requestAnimationFrame(animate)
  }

  window.addEventListener('resize', resize)
  resize()
  animate()
}

function destroyStarfield() {
  if (starfieldAnimId) {
    cancelAnimationFrame(starfieldAnimId)
    starfieldAnimId = null
  }
  warpFactor = 1
  warpTarget = 1
  warpScale = 1
  warpScaleTarget = 1
}

// ─── Démarrage hors Vue (ajouté pour l'export) ───────────────────────────────
// Dans le tableau de bord, App.vue appelle initStarfield() au montage et
// déclenche triggerWarp() à chaque changement de page. Ici : au chargement,
// et le warp reste accessible via l'événement d'origine.
window.addEventListener('maf-trigger-warp', triggerWarp)
initStarfield()
