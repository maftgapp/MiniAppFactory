# Fonds animés du tableau de bord MAF

Extraits de `packages/dashboard/src/App.vue` (branche feat/63-decor-halloween, 2026-10-20).
CSS et JS copiés **tels quels** — aucun réglage visuel modifié.

## theme-maf-ciel/  (thème « MAF », clé interne `oled`)
- `nuages/` : 6 PNG d'origine (`packages/dashboard/src/assets/clouds/`)
- `ciel.css` : dégradé #21BCFF → #a0e9ff + animation `moveCloud` des 20 éléments
- `index.html` : démo autonome (5 traînées + 15 nuages)

## theme-oled-starfield/  (thème « OLED », clé interne `sombre`)
- Aucune image : 70 étoiles dessinées sur `<canvas>`, fond #000
- `starfield.js` : `initStarfield()`, `destroyStarfield()`, `triggerWarp()`
  (accélération × 20 + zoom 1.08 pendant 350 ms, déclenchée par l'événement `maf-trigger-warp`)
- `index.html` : démo autonome, bouton « Warp »

## Voir les démos
- `demo-tout-en-un.html` (dans chaque dossier) : CSS, JS et images intégrés → s'ouvre en double-clic.
- `index.html` : version fichiers séparés, à ouvrir via un serveur local (`python3 -m http.server`).
